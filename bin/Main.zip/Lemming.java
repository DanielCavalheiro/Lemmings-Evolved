public class Lemming {

    private char tribe;
    private int power;

    public Lemming(char tribe, int power) {

        this.tribe = tribe;
        this.power = power;

    }

    public int getPower() {
        return power;
    }

    public char getTribe() {
        return tribe;
    }

}
